
@extends( auth()->user()->id_categoria == 1 ? 'Layout/_LayoutSU' : 'Layout/_Layout')

   





@section('ProfiImage')
{{ auth()->user()->profile_image }}
@endsection


@section('namesidebar')
   {{ auth()->user()->name }}
@endsection

@section('descripcion_puesto')
   {{auth()->user()->descripcion_puesto}}
@endsection

@section('wrapper')
<script>
    $(document).ready(function(){
        $('.treeview').removeClass('active');
        $('#das').addClass('active');
        $('#das1').addClass('active');
    });
</script>
@endsection

