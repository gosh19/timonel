   





<?php $__env->startSection('ProfiImage'); ?>
<?php echo e(auth()->user()->profile_image); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('namesidebar'); ?>
   <?php echo e(auth()->user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('descripcion_puesto'); ?>
   <?php echo e(auth()->user()->descripcion_puesto); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('wrapper'); ?>
<script>
    $(document).ready(function(){
        $('.treeview').removeClass('active');
        $('#das').addClass('active');
        $('#das1').addClass('active');
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make( auth()->user()->id_categoria == 1 ? 'Layout/_LayoutSU' : 'Layout/_Layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>