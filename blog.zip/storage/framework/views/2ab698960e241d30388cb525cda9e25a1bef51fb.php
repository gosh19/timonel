<?php $__env->startSection('ProfiImage'); ?>
<?php echo e(auth()->user()->profile_image); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('descripcion_puesto'); ?>
   <?php echo e(auth()->user()->descripcion_puesto); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('namesidebar'); ?>
   <?php echo e(auth()->user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('wrapper'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script>
  
function limpiarForm(){
  $('#name').val('');
  $('#email').val('');
  $('#password').val('');
  $('#categoria').val('0');
  $('#descripcion_puesto').val('');

}
function validarcampos(){
       var validar=""
        if($('#name').val()==''){
           validar+="Ingrese Nombre \n";
        }
        if($('#email').val()==''){
          validar+="Ingrese Email \n";
        }
        
        if($('#categoria').val()=='0'){
          validar+="Ingrese Categoria \n";
        }
        if($('#descripcion_puesto').val()==''){
          validar+="Ingrese Descripción del Cargo \n";
        }
        if(validar==''){
          validar="OK";
        }
        return validar;
    }
    function table(){
      $('#tableUsuarios').DataTable({
          'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true
       }

        );
    }
    $(document).ready(function(){
     
       
        
      $('.treeview').removeClass('active');
        $('#sistItem').addClass('active');
        $('#sistItem1').addClass('active');
     
          $('#saveUser').click(function (){
           
              var validacion=validarcampos();
              if(validacion!="OK"){
                  alert(validacion);
              }else{
               

                var name=$('#name').val();
                var email=$('#email').val()
                var password=$('#password').val();
                var id_categoria=$('#categoria').val();
                var token=$('#token').val();
                var control=$('#control').val();
                var descripcion_puesto=$('#descripcion_puesto').val();
                var data="name="+name+"&email="+email+"&password="+password+"&role_id="+id_categoria+'&control='+control+'&descripcion_puesto='+descripcion_puesto;
                
                   
                $.ajaxSetup({
                   headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     }
                 });


                $.ajax({
                    method: "post",
                    data: data,
                    url: "<?php echo route('agregar_usuario')?>",
                    success: function(response){ // What to do if we succeed
                    alert(response);
                      location.reload();
                          }
                        
                      });

            }
        });

       



        $('#example1').DataTable()
        $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true
       })  
      
             
      
       
    });
    function editUser(id){
       limpiarForm();
       $.ajaxSetup({
                   headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     }
                 });

                   data="id="+id;
                $.ajax({
                    method: "post",
                    data: data,
                    url: "<?php echo route('edit_usuario')?>",
                    success: function(response){ // What to do if we succeed
                    loadData(response);
                  
                      
                          }
                      });

    }
    function loadData(userRequest){
      
      
         $('#modal-default').modal('show');
         $('#name').val(userRequest.name);
         $('#email').val(userRequest.email);
         $('#categoria').val(userRequest.id_categoria);
         $('#control').val(userRequest.id);
         $('#descripcion_puesto').val(userRequest.descripcion_puesto);
    }
  function deleteUser(id){
               $.ajaxSetup({
                   headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     }
                 });

                   data="id="+id;
                $.ajax({
                    method: "post",
                    data: data,
                    url: "<?php echo route('delete_usuario')?>",
                    success: function(response){ // What to do if we succeed
                    alert("Usuario Eliminado");
                    location.reload();
                      
                          }
                      });

  }
  
</script>

<div class="callout callout-warning">
        <h4>Recuerda!</h4>
        Ante cualquier error contactar inmediatamente al Administrador del Sistema, el CMR esta en fase de desarrollo.
        
</div>
<section class="content-header">
      <h1>
        Gestión del Sistema
        <small>Gestión de Usuarios</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-laptop"></i> Gestión del Sistema</a></li>
        <li class="active">Gestión de Usuarios</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
                <br>
              <h3 class="box-title">Registro de Usuarios Activos</h3>
            </div>
            
            <!-- /.box-header -->
            <div class="box-body">
            <button type="button" onClick="limpiarForm();" class="btn btn-default" data-toggle="modal" data-target="#modal-default">
                Ingresar Usuario
              </button>
              <br>
              <br>
              <table id="tableUsuarios" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>#id</th>
                  <th>Nombre</th>
                  <th>Correo Electronico</th>
                  <th>Cargo</th>                  
                  <th>Categoria</th>
                  <th>Accion</th>
                </tr>
                </thead>
                <tbody>
                   <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                         <?php if($item->id_categoria!=1): ?>
                        <th><?php echo e($item->id); ?></th>
                        <th><?php echo e($item->name); ?></th>
                        <th><?php echo e($item->email); ?></th>
                        <th><?php echo e($item->descripcion_puesto); ?></th>
                        <th><?php echo e($item->role->name); ?></th>
                        <th><a href="javascript:editUser(<?php echo e($item->id); ?>);"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        <a href="javascript:deleteUser(<?php echo e($item->id); ?>);"><button class="btn btn-danger"><i class="fa fa-eraser"></i></button></a>
                        </th>
                          <?php endif; ?>
                     </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                   <th>#id</th>
                  <th>Nombre</th>
                  <th>Correo Electronico</th>
                  <th>Cargo</th>
                  <th>Categoria</th>
                  <th>Accion</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    <div class="modal fade" id="modal-default">
          <div class="modal-dialog bs-example-modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">ABM Usuarios</h4>
              </div>
              <div class="modal-body">
                 <form role="form" id="formuser">
                 <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                        <div class="form-group">
                        <input id="control" type="hidden" value="0">
                        <input id="token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                            <label for="exampleInputEmail1">Nombre</label>
                            <input type="text" class="form-control" id="name" placeholder="Ingrese Nombre">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="email" class="form-control" id="email" placeholder="Ingrese Correo">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Contraseña</label>
                            <input type="password" class="form-control" id="password" placeholder="Contraseña">
                        </div>
                        <div class="form-group">
                            <label for="descripcion">Descripción del Cargo</label>
                            <input type="text" class="form-control" id="descripcion_puesto" placeholder="Descripción del Cargo">
                        </div>
                        <div class="form-group">
                            <label>Categoria</label>
                            <select class="form-control" id="categoria">
                            <option value="0">--Seleccionar--</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($itemr->id!=1): ?>
                                  <option value="<?php echo e($itemr->id); ?>"><?php echo e($itemr->name); ?></option>
                                  <?php endif; ?>     
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!--div class="form-group">
                           <label for="exampleInputFile">Imagen de Perfil</label>
                           <input type="file" id="profile_image">
                           <p class="help-block">Imagen que no supere 2 MB.</p>
                        </div-->
                        
                    </div>
                 
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cerrar</button>
                <button type="button" id="saveUser" class="btn btn-primary">Guardar Cambios</button>
              </div>
              </form>
            </div>
          </div>
    </div>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make( auth()->user()->id_categoria == 1 ? 'Layout/_LayoutSU' : 'Layout/_Layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>