<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Empresa;
class EmpresaController extends Controller
{

    public function edit(Request $request){
                     

    }
    public function add(Request $request){
           $test=$request->razon_social;

    if($request->hasFile('clave_en')&&$request->hasFile('cert')){
        
            


        $clave= $request->file('clave_en');
        $cert= $request->file('cert');
        
        $clavename=$clave->getClientOriginalName();
        $certname=$cert->getClientOriginalName();
        /*
        $clave->move(storage_path().);
        $cert->move(storage_path().);*/

        $path = $request->file('clave_en')->storeAS(
            'CRT/'.$test,$clavename
        );

        $path1 = $request->file('cert')->storeAS(
            'CRT/'.$test,$certname
        );       
              

        Empresa::insert([
                "razon_social"=>$request->razon_social,
                "usuariosPermitidos"=>$request->usuariosPermitidos,
                "cuit"=>$request->cuit,
                "direccion"=>$request->direccion,
                "telefono"=>$request->telefono,
                "responsable"=>$request->responsable,
                "telefono_responsable"=>$request->telefono_responsable,
                "correo"=>$request->correo,
                "clave_p12"=>$path,
                "certificado"=>$path1,
                "clave"=>$request->clave,
                "condicion_fiscal"=>$request->condicion_fiscal,
        ]);
/*
        $path1 = $request->file('clave_en')->store($clavename,'CRT');
        $path = $request->file('cert')->store($certname,'CRT');*/
        $empresas=Empresa::all();

         
        return redirect()->to('empresa');
    }else{
        $empresas=Empresa::all();

        return redirect()->to('empresa');
    }

    }
}
