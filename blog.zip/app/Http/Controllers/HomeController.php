<?php

namespace App\Http\Controllers;
use App\Role;
use App\User;
use App\Empresa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class HomeController extends Controller
{
 public function inicio(){
    if (Auth::check()) {
        
        return view('Dashboard');  
    }else{
        return view('Home');
    }
    
 }

 public function empresa(){
    if (Auth::check()) {
        $empresas=Empresa::all();

        return view('ABMS/Empresa',compact('empresas'));  
    }else{
        return view('Home');
    }
 }

 public function initsesion(){
    if (Auth::check()) {
        return view('Dashboard');   
    }else{
        $User = User::where('ip_client', \Request::ip())->first();
        if($User!=null){
            $profile_image=$User->profile_image;
            $email=$User->email;
            $name=$User->name;
            return view('lockscreen',['name' => $name,'profile'=>$profile_image,'email'=>$email]);
        }else{
            return view('Home');
        }
    }
 }

 public function Usuarios(){
    if (Auth::check()) {
        $users=User::all();
        $roles=Role::all();

        return view('ABMS/Usuarios',compact('users','roles'));

    }else{
        $User = User::where('ip_client', \Request::ip())->first();
        if($User!=null){
            $profile_image=$User->profile_image;
            $email=$User->email;
            $name=$User->name;
            return view('lockscreen',['name' => $name,'profile'=>$profile_image,'email'=>$email]);
        }else{
            return view('/');
        }
    }
 }
 public function lockscreen(){
         return view('lockscreen');
 }

}
