<?php

//Rutas a views
Route::get('/', 'HomeController@inicio');
Route::get('Usuarios', 'HomeController@Usuarios')->name('Usuarios');


//fin rutas
//ruta de formulario login
Route::post('login','Auth\LoginController@login')->name('login');
Route::get('logout','Auth\LoginController@logout')->name('logout');
//ruta al dasboard
Route::get('dashboard','HomeController@initsesion')->name('dashboard');
             
//rutas para google
Route::get('redirectgo', 'Auth\LoginController@redirectToProvider'); 
Route::get('logdas', 'Auth\LoginController@handleProviderCallback');

//lockscreen 
Route::get('lockscreen','HomeController@lockscreen')->name('lockscreen');
//useer
Route::post('agregar_usuario','UsuariosController@agregar_usuario')->name("agregar_usuario");
Route::post('delete_usuario','UsuariosController@delete')->name("delete_usuario");
Route::post('edit_usuario','UsuariosController@edit')->name("edit_usuario");
Route::post('cargarUsers','UsuariosController@cargarUsers')->name('cargarUsers');

//empresa
//aqui tendria que ir el middleware

//empresa
Route::get('empresa','HomeController@empresa')->name('empresa');
Route::post('agregar_empresa','EmpresaController@add')->name('agregar_empresa');
Route::post('edit_empresa','EmpresaController@edit')->name('edit_empresa');